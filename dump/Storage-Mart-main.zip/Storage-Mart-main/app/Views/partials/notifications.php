<?php
$base = rtrim(BASE_URL, '/');
?>
<li class="nav-item dropdown no-arrow mx-1">
    <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown"
       role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-bell fa-fw"></i>

        <?php if ($count > 0): ?>
            <span class="badge badge-danger badge-counter">
                <?= $count > 9 ? '9+' : $count ?>
            </span>
        <?php endif; ?>
    </a>

    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
         aria-labelledby="alertsDropdown">

        <h6 class="dropdown-header">Alerts Center</h6>

        <?php if (empty($notifications)): ?>
            <div class="dropdown-item text-center small text-gray-500">
                No new alerts
            </div>
        <?php else: ?>
            <?php foreach ($notifications as $n): ?>
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <div class="mr-3">
                        <div class="icon-circle bg-<?= htmlspecialchars($n['bg_color']) ?>">
                            <i class="fas <?= htmlspecialchars($n['icon']) ?> text-white"></i>
                        </div>
                    </div>
                    <div>
                        <div class="small text-gray-500">
                            <?= date('F d, Y', strtotime($n['created_at'])) ?>
                        </div>
                        <?= htmlspecialchars($n['message']) ?>
                    </div>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>

        <a class="dropdown-item text-center small text-gray-500" href="/notifications">
            Show All Alerts
        </a>
    </div>
</li>
